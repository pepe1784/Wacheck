/*
 * EJEMPLO DE USO DEL SISTEMA DE SONIDOS
 * =====================================
 * 
 * Este archivo muestra ejemplos de cómo usar el nuevo sistema de sonidos
 * en diferentes partes del juego.
 */

// =====================================================
// EJEMPLO 1: Sonidos de Interfaz
// =====================================================

function onButtonClick() {
    // ANTES:
    // playSound(400, 0.1, 'square', 0.15);
    
    // AHORA:
    GameSounds.click();
}

function onButtonHover() {
    // ANTES:
    // playSound(300, 0.05, 'sine', 0.1);
    
    // AHORA:
    GameSounds.hover();
}

function onBackButton() {
    // ANTES:
    // playSound(300, 0.1, 'square', 0.15);
    
    // AHORA:
    GameSounds.back();
}

// =====================================================
// EJEMPLO 2: Sonidos de Juego
// =====================================================

function onPlaceDefender() {
    // ANTES:
    // playSound(500, 0.15, 'triangle', 0.2);
    
    // AHORA:
    GameSounds.placeDefender();
    
    // El juego colocará el defensor...
}

function onSelectDefender() {
    // ANTES:
    // playSound(450, 0.1, 'sine', 0.15);
    
    // AHORA:
    GameSounds.selectDefender();
}

function onRemoveDefender() {
    // ANTES:
    // playSound(250, 0.2, 'sawtooth', 0.2);
    
    // AHORA:
    GameSounds.removeDefender();
    
    // Devolver el 50% de monedas...
}

function onUpgradeDefender() {
    // ANTES:
    // playSound(700, 0.3, 'triangle', 0.25);
    
    // AHORA:
    GameSounds.upgradeDefender();
    
    // Mejorar el defensor...
}

// =====================================================
// EJEMPLO 3: Sonidos de Combate
// =====================================================

function defenderShoot() {
    // ANTES:
    // playSound(350, 0.08, 'square', 0.1);
    
    // AHORA:
    GameSounds.shoot();
    
    // Crear proyectil...
}

function projectileHit() {
    // ANTES:
    // playSound(200, 0.1, 'sine', 0.12);
    
    // AHORA:
    GameSounds.hit();
    
    // Aplicar daño al contaminante...
}

function contaminatorKilled() {
    // ANTES:
    // playSound(800, 0.2, 'triangle', 0.2);
    
    // AHORA:
    GameSounds.kill();
    
    // Dar monedas al jugador...
}

function baseDamaged() {
    // ANTES:
    // playSound(150, 0.3, 'sawtooth', 0.25);
    
    // AHORA:
    GameSounds.hurt();
    
    // Reducir vida de la base...
}

// =====================================================
// EJEMPLO 4: Sonidos de Oleadas
// =====================================================

function startWave() {
    // ANTES:
    // playSound(600, 0.4, 'triangle', 0.3);
    
    // AHORA:
    GameSounds.waveStart();
    
    // Iniciar spawning de enemigos...
}

function completeWave() {
    // ANTES:
    // playSound(800, 0.5, 'sine', 0.35);
    
    // AHORA:
    GameSounds.waveComplete();
    
    // Dar recompensas...
}

function gameOver() {
    // ANTES:
    // playSound(100, 0.8, 'sawtooth', 0.4);
    
    // AHORA:
    GameSounds.gameOver();
    
    // Mostrar pantalla de derrota...
}

function gameVictory() {
    // ANTES:
    // playSound(1000, 0.6, 'sine', 0.4);
    
    // AHORA:
    GameSounds.victory();
    
    // Mostrar pantalla de victoria...
}

// =====================================================
// EJEMPLO 5: Sonidos Especiales
// =====================================================

function earnCoins(amount) {
    // ANTES:
    // playSound(600, 0.15, 'sine', 0.2);
    
    // AHORA:
    GameSounds.coin();
    
    // Sumar monedas...
}

function unlockDefender() {
    // ANTES:
    // playSound(800, 0.4, 'triangle', 0.3);
    
    // AHORA:
    GameSounds.unlock();
    
    // Desbloquear defensor...
}

function achievementUnlocked() {
    // ANTES:
    // playSound(900, 0.5, 'sine', 0.35);
    
    // AHORA:
    GameSounds.achievement();
    
    // Mostrar notificación de logro...
}

function applyPowerup() {
    // ANTES:
    // playSound(650, 0.3, 'triangle', 0.25);
    
    // AHORA:
    GameSounds.powerup();
    
    // Aplicar mejora...
}

function criticalHit() {
    // ANTES:
    // playSound(1200, 0.2, 'square', 0.3);
    
    // AHORA:
    GameSounds.critical();
    
    // Mostrar efecto de crítico...
}

// =====================================================
// EJEMPLO 6: Sonidos de Recompensas
// =====================================================

function claimReward() {
    // ANTES:
    // playSound(750, 0.4, 'sine', 0.3);
    
    // AHORA:
    GameSounds.reward();
    
    // Dar recompensa al jugador...
}

function defenderLevelUp() {
    // ANTES:
    // playSound(850, 0.5, 'triangle', 0.35);
    
    // AHORA:
    GameSounds.levelUp();
    
    // Mejorar estadísticas del defensor...
}

function missionComplete() {
    // ANTES:
    // playSound(900, 0.5, 'sine', 0.35);
    
    // AHORA:
    GameSounds.mission();
    
    // Mostrar recompensas de misión...
}

// =====================================================
// EJEMPLO 7: Uso en HTML
// =====================================================

/*
ANTES:
<button onclick="playSound(400, 0.1, 'square', 0.15); doSomething()">
    Click me
</button>

AHORA:
<button onclick="GameSounds.click(); doSomething()">
    Click me
</button>
*/

// =====================================================
// EJEMPLO 8: Uso Condicional
// =====================================================

function onDefenderAction(actionType) {
    switch(actionType) {
        case 'place':
            GameSounds.placeDefender();
            break;
        case 'upgrade':
            GameSounds.upgradeDefender();
            break;
        case 'remove':
            GameSounds.removeDefender();
            break;
    }
}

// =====================================================
// EJEMPLO 9: Combinación de Sonidos
// =====================================================

function onMajorAchievement() {
    // Reproducir múltiples sonidos en secuencia
    GameSounds.achievement();
    
    setTimeout(() => {
        GameSounds.powerup();
    }, 500);
    
    setTimeout(() => {
        GameSounds.unlock();
    }, 1000);
}

// =====================================================
// EJEMPLO 10: Verificar si un Sonido Existe
// =====================================================

function playSoundSafely(soundName) {
    if (typeof GameSounds !== 'undefined' && GameSounds[soundName]) {
        GameSounds[soundName]();
    } else {
        console.warn(`Sonido no disponible: ${soundName}`);
    }
}

// Uso:
playSoundSafely('click');
playSoundSafely('nonExistentSound'); // No causará error
