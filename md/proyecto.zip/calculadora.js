// === FUNCIONALIDAD DE LA CALCULADORA ===

// Valores de consumo de agua (realistas para México)
const waterConsumption = {
    shower: 8,  // litros por minuto
    teeth: 2,   // litros por vez
    hands: 0.5, // litros por vez
    dishes: 20, // litros por vez
    cooking: 1, // litros directos
    laundry: 80, // litros por carga
    car: 200,   // litros por lavado con manguera
    carBucket: 40, // litros por lavado con cubetas
    plants: 3   // litros por minuto
};

// Precio del agua en Colima (aproximado)
const waterPricePerLiter = 0.01; // 1 centavo por litro

function showWaterCalculator() {
    document.getElementById('mainPage').style.display = 'none';
    document.getElementById('userPanel').style.display = 'none';
    document.getElementById('calculatorContainer').style.display = 'block';
    if (typeof initAudio === 'function') initAudio(); // Llama a initAudio si existe
    // Calcular valores iniciales
    calculateWater();
    // Configurar event listeners para recálculo automático
    document.querySelectorAll('#calculatorContainer input[type="number"]').forEach(input => {
        input.addEventListener('input', calculateWater);
    });
}

function backToMainFromCalculator() {
    if (typeof playSound === 'function') playSound(300, 0.1, 'square', 0.15);
    document.getElementById('mainPage').style.display = 'block';
    document.getElementById('userPanel').style.display = 'block';
    document.getElementById('calculatorContainer').style.display = 'none';
    if (typeof updateUnlockShop === 'function') updateUnlockShop();
}

function calculateWater() {
    const showers = parseInt(document.getElementById('showers').value) || 0;
    const showerMinutes = parseInt(document.getElementById('shower-minutes').value) || 10;
    const teeth = parseInt(document.getElementById('teeth').value) || 0;
    const hands = parseInt(document.getElementById('hands').value) || 0;
    const dishes = parseInt(document.getElementById('dishes').value) || 0;
    const cooking = parseInt(document.getElementById('cooking').value) || 0;
    const laundry = parseInt(document.getElementById('laundry').value) || 0;
    const car = parseInt(document.getElementById('car').value) || 0;
    const plants = parseInt(document.getElementById('plants').value) || 0;

    // Calcular consumos individuales
    const showerTotal = showers * showerMinutes * waterConsumption.shower;
    const teethTotal = teeth * waterConsumption.teeth;
    const handsTotal = hands * waterConsumption.hands;
    const dishesTotal = dishes * waterConsumption.dishes;
    const cookingTotal = cooking * waterConsumption.cooking;
    const laundryTotal = laundry * waterConsumption.laundry;
    const carTotal = (car / 7) * waterConsumption.car; // Dividir por semana
    const plantsTotal = plants * waterConsumption.plants;

    // Actualizar displays individuales
    document.getElementById('shower-total').textContent = showerTotal.toFixed(0);
    document.getElementById('teeth-total').textContent = teethTotal.toFixed(0);
    document.getElementById('hands-total').textContent = handsTotal.toFixed(0);
    document.getElementById('dishes-total').textContent = dishesTotal.toFixed(0);
    document.getElementById('cooking-total').textContent = cookingTotal.toFixed(0);
    document.getElementById('laundry-total').textContent = laundryTotal.toFixed(0);
    document.getElementById('car-total').textContent = Math.round(carTotal);
    document.getElementById('plants-total').textContent = plantsTotal.toFixed(0);

    // Calcular total
    const totalWater = showerTotal + teethTotal + handsTotal + dishesTotal +
                     cookingTotal + laundryTotal + carTotal + plantsTotal;

    document.getElementById('total-water').textContent = Math.round(totalWater);

    // Calcular costos
    const dailyCost = totalWater * waterPricePerLiter;
    const monthlyCost = dailyCost * 30;

    document.getElementById('estimated-cost').textContent = dailyCost.toFixed(2);
    document.getElementById('monthly-cost').textContent = monthlyCost.toFixed(2);

    // Clasificar consumo
    let classification = '';
    let classificationClass = '';

    if (totalWater < 100) {
        classification = 'Consumo Bajo - Excelente';
        classificationClass = 'bajo';
    } else if (totalWater < 200) {
        classification = 'Consumo Moderado';
        classificationClass = 'moderado';
    } else if (totalWater < 300) {
        classification = 'Consumo Alto';
        classificationClass = 'alto';
    } else {
        classification = 'Consumo Excesivo';
        classificationClass = 'excesivo';
    }

    const classElement = document.getElementById('classification');
    classElement.textContent = classification;
    classElement.className = `classification ${classificationClass}`;

    // Generar recomendaciones personalizadas
    generatePersonalizedTips(showerTotal, carTotal, dishesTotal, totalWater);
}

function generatePersonalizedTips(showerTotal, carTotal, dishesTotal, totalWater) {
    const tips = [];

    if (showerTotal > 100) {
        tips.push({
            icon: '🚿',
            text: `Tus duchas consumen ${Math.round(showerTotal)} litros. Reducir 2 minutos ahorraría ${Math.round(showerTotal * 0.25)} litros diarios.`
        });
    }

    if (carTotal > 20) {
        tips.push({
            icon: '🚗',
            text: `Lavar el carro con cubetas en vez de manguera te ahorraría ${Math.round(carTotal - (carTotal * 0.2))} litros por lavado.`
        });
    }

    if (dishesTotal > 60) {
        tips.push({
            icon: '🍽️',
            text: `Llenar el fregadero en vez de lavar con grifo abierto puede ahorrar hasta 20 litros por lavado.`
        });
    }

    if (totalWater > 250) {
        tips.push({
            icon: '💧',
            text: `Tu consumo está por encima del promedio. Implementar estos consejos podría reducir tu consumo en un 25%.`
        });
    }

    if (tips.length === 0) {
        tips.push({
            icon: '🌟',
            text: '¡Felicidades! Tu consumo está dentro de rangos eficientes. Sigue así y comparte estos consejos.'
        });
    }

    // Mostrar tips
    const tipsContainer = document.getElementById('personalized-tips');
    tipsContainer.innerHTML = '';

    tips.forEach(tip => {
        const tipElement = document.createElement('div');
        tipElement.className = 'tip-item';
        tipElement.innerHTML = `
            <span class="tip-icon">${tip.icon}</span>
            <span>${tip.text}</span>
        `;
        tipsContainer.appendChild(tipElement);
    });
}

function resetCalculator() {
    const inputs = document.querySelectorAll('#calculatorContainer input[type="number"]');
    inputs.forEach(input => {
        if (input.id === 'shower-minutes') input.value = 10;
        else if (input.id === 'teeth') input.value = 3;
        else if (input.id === 'hands') input.value = 8;
        else if (input.id === 'dishes') input.value = 2;
        else if (input.id === 'cooking') input.value = 5;
        else if (input.id === 'plants') input.value = 10;
        else input.value = input.id === 'showers' || input.id === 'laundry' ? 1 : 0;
    });
    calculateWater();
}

function finishCalculator() {
    const calculatorCompleted = gameState.currentUser?.calculatorCompleted || false;

    if (!calculatorCompleted) {
        gameState.specialCoins += 2;
        if (gameState.currentUser) {
            gameState.currentUser.calculatorCompleted = true;
        }
        saveCurrentUserProgress();
        updateUnlockShop();
        playSound(1000, 0.4, 'triangle', 0.3);
        showMessage("¡Calculadora Completada!", "Has aprendido sobre el consumo de agua. ¡Recibiste 2 monedas especiales como recompensa!", [{ text: 'Genial', action: () => { hideMessage(); backToMainFromCalculator(); }}]);
    } else {
        showMessage("Calculadora Completada", "Gracias por usar la calculadora de agua. La recompensa solo se otorga la primera vez.", [{ text: 'Entendido', action: () => { hideMessage(); backToMainFromCalculator(); }}]);
    }
}